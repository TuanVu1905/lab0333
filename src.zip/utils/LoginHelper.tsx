export const dataLogin = {
     id: 0 ,
     name: '',
     photo : '',
     email:''
}